<?php include 'insert.php' ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Pressure Monitoring App</title>

    <!--CSS-->
    <link rel="stylesheet" href="css/jquery.mobile-1.3.1.min.css">
    <link rel="stylesheet" 
      href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
      integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u"
      crossorigin="anonymous">
    
    <!--JS-->
    <script src="scripts/jquery-1.8.3.min.js"></script>
    <script src="scripts/chromeFileProtocolFix.js"></script>
    <script src="scripts/jquery.mobile-1.3.1.min.js"></script>
  </head>
  <body>
    <!--User Login Page-->
    <div data-role="page" id="pageUserLogin">
      <div data-role="header">
        <h1>User Login</h1>
      </div>

      <div data-role="content">
        <label for="passcode">Password:</label>
        <input type="password" id="passcode">

        <div data-role="controlgroup" id="numKeyPad">
          <a href="#" data-role="button" id="btnEnter" type="submit">
              Enter</a>
          <a href="#pageAbout" data-role="button">About</a>
        </div>
        <div data-role="controlgroup" data-type="horizontal">
          <a data-role="button" onclick="addValueToPassword(7);">7</a>
          <a data-role="button" onclick="addValueToPassword(8);">8</a>
          <a data-role="button" onclick="addValueToPassword(9);">9</a>
        </div>
        <div data-role="controlgroup" data-type="horizontal">
          <a data-role="button" onclick="addValueToPassword(4);">4</a>
          <a data-role="button" onclick="addValueToPassword(5);">5</a>
          <a data-role="button" onclick="addValueToPassword(6);">6</a>
        </div>
        <div data-role="controlgroup" data-type="horizontal">
          <a data-role="button" onclick="addValueToPassword(1);">1</a>
          <a data-role="button" onclick="addValueToPassword(2);">2</a>
          <a data-role="button" onclick="addValueToPassword(3);">3</a>
        </div>
        <div data-role="controlgroup" data-type="horizontal">
          <a data-role="button" onclick="addValueToPassword(0);">0</a>
          <a data-role="button" onclick="addValueToPassword('bksp');"
            data-icon="delete">del</a>
        </div>
      </div>
    </div>

    <!--Disclaimer Page-->
    <div data-role="page" id="legalNotice" data-close-btn="none">
      <div data-role="header">
        <h1>Disclaimer</h1>
      </div>

      <div data-role="content">
        <p>
         This app is not intended to replace the expertise of a healthcare 
         provider. Always consult your primary care provider or specialist 
         for any questions or concerns regarding your health, medications,
         or any other aspect of your treatment regimen. In order to proceed,
         please click on the button below if you understand and will comply 
         with these terms and conditions.<br>
        </p>
        <a href="#pageUserInfo" id="noticeYes" data-role="button"
          data-icon="forward" data-mini="false">Yes</a>
      </div>
    </div>

    <!--About Page-->
    <div data-role="page" id="pageAbout">
      <div data-role="header">
        <a href="#pageMenu" data-role="button" data-icon="bars"
          data-iconpos="left">Home</a>
        <h1>Info</h1>
      </div>

      <div data-role="content">
        <p>
         This web application will track your blood pressure. Hypertension - 
         commonly known as high blood pressure - plagues many people and 
         typically does not cause any symptoms which is why this
         condition is often referred to as being "silent but deadly." 
         Prolonged high blood pressure can damage the heart and kidneys, 
         and increases the risk of stroke, heart disease and attack. 
         Fortunately, high blood pressure can be managed with healthy eating 
         including following a low sodium diet, weight and stress management, 
         medication,and exercise; this app will help you ensure that your 
         blood pressure remains on the right track!
        </p>
      </div>
    </div>

    <!--User Information Page/Form-->
    <div data-role="page" id="pageUserInfo">
      <div data-role="header">
        <a href="#pageMenu" data-role="button" data-icon="bars"
          data-iconpos="left" data-inline="true">Menu</a>
        <a href="#pageAbout" data-role="button" data-icon="info"
          data-iconpos="right" data-inline="true">Info</a>
        <h1>User Information</h1>
      </div>

      <div data-role="content">
        <form id="frmUserForm" method="post" action="insert.php">
          <div data-role="fieldcontain">
            <label for="txtFirstName">First Name: </label>
            <input type="text" placeholder="First Name" name="txtFirstName"
              data-mini="false" id="txtFirstName" value="" required>
          </div>

          <div data-role="fieldcontain">
            <label for="txtLastName">Last Name: </label>
            <input type="text" placeholder="Last Name" name="txtLastName"
              data-mini="false" id="txtLastName" value="" required>
          </div>

          <div data-role="fieldcontain">
            <label for="datBirthdate">Date of Birth: </label>
            <input type="date" name="datBirthdate" data-mini="false"
              id="datBirthdate" value="" required>
          </div>

          <div data-role="fieldcontain">
            <label for="changePassword">Edit Password: </label>
            <input type="password" placeholder="New Password"
              name="changePassword" data-mini="false" id="changePassword"
              value="" required>
          </div>         

          <input type="submit" id="btnUserUpdate" data-icon="check"
            data-iconpos="left" value="Update" data-inline="true" name="update">
        </form>
      </div>
    </div>

    <!--Menu Page-->
    <div data-role="page" id="pageMenu">
      <div data-role="header">
        <a href="#pageMenu" data-role="button" data-icon="bars"
          data-iconpos="left" data-inline="true">Menu</a>
        <a href="#pageAbout" data-role="button" data-icon="info"
          data-iconpos="right" data-inline="true">Info</a>
        <h1>Blood Pressure Monitoring App</h1>
      </div>

      <div data-role="content">
        <div data-role="controlgroup">
          <a href="#pageUserInfo" data-role="button">User Info</a>
          <a href="#pageRecords" data-role="button">Records</a>
        </div>
      </div>
    </div>

    <!--Records Page-->
    <div data-role="page" id="pageRecords">
      <div data-role="header">
        <a href="#pageMenu" data-role="button" data-icon="bars"
          data-iconpos="left" data-inline="true">Menu</a>
        <a href="#pageAbout" data-role="button" data-icon="info"
          data-iconpos="right" data-inline="true">Info</a>
        <h1>Records</h1>
      </div>

      <div data-role="content">
        <!--User's Information Section-->
        <div data-role="fieldcontain" id="divUserSection">

        </div>

        <h2 style="text-align: center;">History</h2>
        
        <div data-role="fieldcontain">
          
            <!--Records Table-->
          <table id="tblRecords" class="ui-responsive table-stroke">

          </table>
        </div>

        <div data-role="fieldcontain">
          <a href="#pageNewRecordForm" id="btnAddRecord" data-role="button"
            data-icon="plus">Add New Entry</a>
          <a href="#" data-role="button" id="btnClearHistory"
            data-icon="delete">Clear History</a>
        </div>
      </div>
    </div>

    <!--New Record Form Page-->
    <div data-role="page" id="pageNewRecordForm">
      <div data-role="header">
        <a href="#pageMenu" data-role="button" data-icon="bars"
          data-iconpos="left" data-inline="true">Menu</a>
        <a href="#pageAbout" data-role="button" data-icon="info"
          data-iconpos="right" data-inline="true">Info</a>
        <h1>New Record</h1>
      </div>

      <div data-role="content">
        <form id="frmNewRecordForm" action="">
          <div data-role="fieldcontain">
            <div data-role="fieldcontain">
              <label for="datExamDate">Date: </label>
              <input type="date" name="datExamDate" data-mini="false"
                id="datExamDate" value="" required>
            </div>

            <div data-role="fieldcontain">
              <label for="txtSBP">
                Systolic:
              </label>
              <input type="number" placeholder="0" name="txtSBP"
                data-mini="false" id="txtSBP" min="0" max="300" value="">
            </div>

            <div data-role="fieldcontain">
              <label for="txtDBP">
                Diastolic:
              </label>
              <input type="number" placeholder="0" min="0" max="300"
                name="txtDBP" data-mini="false" id="txtDBP"
                value="">
              </div>
           </div>
              
          <input type="submit" id="btnSubmitRecord" value="">
        </form>
        <p>
          &nbsp;&nbsp;<strong>Systolic blood pressure (SBP)</strong> is the top
          number in your blood pressure reading. It is the maximum amount of
          pressure in your blood vessels when your heart is beating. It is measured
          in millimeters of mercury (mmHg). Based on the latest research,
          it was determined that the target SBP reading for adults should be
          130 mmHg or less.<br>
        </p>
        <p>
          &nbsp;&nbsp;<strong>Diastolic blood pressure (DBP)</strong> is the 
          bottom number in your blood pressure reading. It is the minimum amount 
          of pressure in your blood vessels when your heart is resting between beats. 
          It is also measured in millimeters of mercury (mmHg). Based on the latest
          research, it was determined that the target DBP for adults should be 
          80mmHg or less.<br>
        </p>
        <table id="bp">
          <caption>Blood Pressure Stages</caption>
            <thead>
              <tr>
                <th>Blood Pressure Category</th> 
                <th>Systolic mmHg <br /> (upper number)</th>
                <th></th>
                <th>Diastolic mmhg <br /> (lower number)</th>
              </tr>
            </thead>
            <tbody>
             <tr>
               <td>Low blood pressure (hypotension)</td> 
               <td>less than 80</td>
               <td>or</td> 
               <td>less than 60</td>
             </tr>
             <tr>
               <td>Normal</td>
               <td>80-120</td>
               <td>and</td>
               <td>60-80</td>
             </tr>
             <tr>
               <td>Prehypertension</td>
               <td>120-139</td>
               <td>or</td>
               <td>80-89</td>
             </tr>    
             <tr>
               <td>High blood pressure <br /> (Hypertension Stage I)</td>
               <td>140-159</td>
               <td>or</td>
               <td>90-99</td>
             </tr>
             <tr>
               <td>High blood pressure <br /> (Hypertension Stage II</td>
               <td>160 or higher</td>
               <td>or</td>
               <td>100 or higher</td>
             </tr>
             <tr>
               <td>High Blood Pressure Crisis <br /> (Seek emergency care)</td>
               <td>higher than 180</td>
               <td>or</td>
               <td>higher than 110</td>
             </tr>
          </tbody>
        </table>
          <p>Source: American Heart Association</p>
      </div>
    </div>


    <!--Custom JavaScript files-->
    <script src="scripts/login.js"></script>
    <script src="scripts/userForm.js"></script>
    <script src="scripts/pageLoader.js"></script>
    <script src="scripts/records.js"></script>
  </body>
</html>