"use strict";
/*
   addValuetoPassword will add value to the password and will remove the last 
   value of the current value when the backspace button is pressed. 
*/
function addValueToPassword(key) {
  var currVal = $("#passcode").val();
  if (key == "bksp") {
    $("#passcode").val(currVal.substring(0, currVal.length - 1));
  } else {
    $("#passcode").val(currVal.concat(key));
  }
}
        
/*
  getPassword function will check to see if local storage is available; if not it 
  will alert the user. This function will also check to see if the user exists in 
  local storage and will return the saved password of the user. 
*/

function getPassword() {
  if (typeof(Storage) == "undefined") {
    alert("Your browser does not support HTML5 localStorage. Try upgrading.");
  } else if (localStorage.getItem("user") != null) {
    return JSON.parse(localStorage.getItem("user")).NewPassword;
  } else {
    return "2345"; // Default password
  }
}

/*
  The onclick function will retrieve value of passcode element and call the
  getPassword function, checking the value to ensure that they match. If the 
  passcodes do not match, an alert will pop up informing the user and that 
  they need to try entering the password again. 
*/
$("#btnEnter").click( function() {
  var enteredPasscode = $("#passcode").val();
  var storedPasscode = getPassword();

  if(enteredPasscode == storedPasscode) {
    // checks whether user has agreed to disclaimer
    if (localStorage.getItem("agreedToLegal") == null) {
      $("#btnEnter").attr("href", "#legalNotice").button();
    } else if (localStorage.getItem("agreedToLegal") == "true") {
        // checks whether a user profile has been saved
      if (localStorage.getItem("user") == null) {
        $("#btnEnter").attr("href", "#pageUserInfo").button();
      } else {
          $("#btnEnter").attr("href", "#pageMenu").button();
      }
    }
  } else {
      alert("Incorrect password, please try again.");
  }
});

/*
  onClick function to noticeYes element will store true value for the 
  agreedToLegal item in localStorage. 
*/
$("#noticeYes").click( function() {
  try {
    localStorage.setItem("#agreedtoLegal", "true");
  } catch(e) {
      if (window.navigator.vendor === "Google Inc.") {
        if (e === DOMException.QUOTA_EXCEEDED_ERR) {
          alert("Error: Saving to local storage");
        }
      } else if (e === QUOTA_EXCEEDED_ERR) {
        alert("Error: Saving to local storage.");
      }
      
      console.log(e);
  }
});