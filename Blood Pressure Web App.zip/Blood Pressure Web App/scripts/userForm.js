"use strict";

/*
  checkUserForm will ensure user enters data into all fields and will alert the 
  user if any particular form is left blank. Alert will also occur if user enters
  a date later than today's date for their birth date. 
*/
function checkUserForm() {
  if ($("#txtFirstName").val() == "") {
    alert("Please enter your first name, it cannot be left blank.");
    return false;
  } else if ($("#txtLastName").val() == "") {
    alert ("Please enter your last name, it cannot be left blank.");
    return false;
  } else if ($("#datBirthdate").val() == "") {
    alert ("Please enter your date of birth, it cannot be left blank.");
    return false; 
  } else if ($("#datBirthdate").val() > getCurrentDateFormatted()) {
    alert ("Are you from the future? Your birthday can't be later than today.");
    return false; 
  } else {
    return true;
  }
}


/*
  getCurrentDateFormatted will format date into mm-dd-yyyy. 
*/
function getCurrentDateFormatted() {
  var date = new Date();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  var year = date.getFullYear();

  var formattedDate = year + "-" + 
    (("" + month).length < 2 ? "0" : "") + month + "-" +
    (("" + day).length < 2 ? "0" : "") + day;

  return formattedDate;
}

    
/*
  frmUserForm submit handler will call the savUserForm() function and return true.
*/
$("#frmUserForm").submit( function() {
  saveUserForm();
  return false;
})

/*
  saveUserForm will save user's information to localStorage. 
*/
    
function saveUserForm() {
  if (checkUserForm()) {
    var user = {
      "FirstName" : $("#txtFirstName").val(),
      "LastName" : $("#txtLastName").val(),
      "NewPassword" : $("#changePassword").val(),
      "DOB" : $("#datBirthdate").val(),
  };
  
  try  {
    localStorage.setItem("user", JSON.stringify(user));
    alert ("Saving Information");
      
    $.mobile.changePage("#pageMenu");
    window.location.reload();
  } catch(e) {
    /*Google browsers use different error constant */
    if (window.navigator.vendor === "Google Inc.") {
      if (e === DOMException.QUOTE_EXCEEDED_ERR) {
        alert("Error: Local Storage limit exceeds.");
      }
    } else if (e === QUOTA_EXCEEDED_ERR) {
      alert("Error: Saving to local storage.");
    }
      
    console.log(e);
    }
  }
}
    

/*
  showUserForm will check localStorage to see if user's information is stored
  there. If it is, the stored data will be loaded into the user form. 
*/
function showUserForm() { 
  try {
    var user = JSON.parse(localStorage.getItem("user"));
  } catch(e) {
    /*Google browsers use different error constant */
    if (window.navigator.vendor === "Google Inc.") {
      if (e === DOMException.QUOTE_EXCEEDED_ERR) {
        alert("Error: Local Storage limit exceeds.");
      } 
    } else if (e === QUOTA_EXCEEDED_ERR) {
      alert("Error: Saving to local storage.");
    }
      
      console.log(e);    
  }

  if (user != null) {
    $("#txtFirstName").val(user.FirstName);
    $("#txtLastName").val(user.LastName);
    $("#changePassword").val(user.NewPassword);
    $("#datBirthdate").val(user.DOB);
  }
}