"use strict";           

/*
  A pageshow handler with an anonymous function that calls the
  showUserForm function when the User Info page is active. It calls
  the loadUserInformation and listRecords function when the Records 
  page is active.
*/
$(document).on("pageshow", function() {
  if ($(".ui-page-active").attr("id") == "pageUserInfo") {
    showUserForm();
  } else if ($(".ui-page-active").attr("id") == "pageRecords") {
    loadUserInformation();
    listRecords();
  }
});